  <footer class="footer footer-default">
    <div class="container">

      <div class="copyright text-center">
        &copy;
        <script>
          document.write(new Date().getFullYear())
        </script> made with <i class="material-icons">favorite</i> by
        <a href="https://aaronjohn-sayoc.github.io/dev-portfolio" target="_blank">Aaron Sayoc.</a>
      </div>
    </div>
  </footer>
